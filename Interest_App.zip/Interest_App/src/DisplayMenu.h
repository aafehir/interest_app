//Aaron Fehir
//February 5, 2021
//Programming Languages
//Project Two

#ifndef DISPLAY_MENU_H
#define DISPLAY_MENU_H

//Create DisplayMenu class
class DisplayMenu {

//Declare public function
public:
  void PrintMenu();

private:
  double m_investment;
  double m_deposit;
  double m_interest;
  int m_years;

};

#endif
