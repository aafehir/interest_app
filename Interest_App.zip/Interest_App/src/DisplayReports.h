//Aaron Fehir
//February 5, 2021
//Programming Languages
//Project Two

#ifndef DISPLAY_REPORTS_H
#define DISPLAY_REPORTS_H

//Create DisplayMenu class
class DisplayReports {

//Declare constructor and public function
public:
  void PrintReports();
  double interestWithoutDeposits;
  double interestWithDeposits;
  double monthlyWithoutDeposits;
  double monthlyWithDeposits;
  double openBalWithoutDeposits;
  double closeBalWithoutDeposits;
  double openBalWithDeposits;
  double closeBalWithDeposits;

};

#endif

