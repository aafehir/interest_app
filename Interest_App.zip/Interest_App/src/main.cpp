//Aaron Fehir
//February 5, 2021
//Programming Languages
//Project Two

//Include DisplayMenu class
#include "DisplayMenu.h"
//Include DisplayReports class
#include "DisplayReports.h"

int main() {

  //Instantiate DisplayMenu and DisplayReports class objects
  DisplayMenu menu;

  menu.PrintMenu();

  return 0;
}





